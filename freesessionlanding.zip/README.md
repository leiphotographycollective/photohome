# Free Engagement Session — Landing Page

This folder is your Facebook/Instagram ad landing page. It's **one file**
(`index.html`) — no code, apps, or installs needed to use it. Before it goes
live you'll do four small things: add your photos, connect the form, add your
Meta Pixel, and put it online. Each takes a few minutes.

---

## 1. Add your photos

Create a folder called **`images`** right next to `index.html`, then drop in
your photos with these exact names:

| File name | Where it appears |
|---|---|
| `hero.jpg` | The big background photo at the top |
| `engagement-1.jpg` … `engagement-4.jpg` | The gallery grid |
| `wedding-5.jpg`, `wedding-6.jpg` | The last two gallery slots |

- **The hero photo appears automatically** once `images/hero.jpg` exists.
  Pick a wide photo that's a little dark or moody — white text sits on top.
- **The gallery photos need one tiny edit each.** Open `index.html` in any
  text editor (TextEdit, Notes, VS Code) and find the six blocks that look
  like this:

  ```html
  <div class="ph">REPLACE: engagement photo 1</div>
  <!-- <img src="images/engagement-1.jpg" alt="..."> -->
  ```

  For each one: **delete the grey-box line** (the one with `REPLACE:` in it)
  and **remove the `<!--` and `-->`** around the `<img …>` line. That's it —
  the grey box becomes your photo. Update the `alt="..."` text to describe
  the photo (this helps accessibility and Google).

**Photo sizing tip:** export images around 1200–1600px wide. Phone visitors
are most of your ad traffic, so smaller files = faster page = cheaper ads.

## 2. Connect the form (Formspree — free)

The form is what turns ad clicks into inquiries, so do this before launching.

1. Go to **formspree.io** and create a free account (use
   leiphotography57@gmail.com so submissions come to you).
2. Click **New form**, name it "Free Engagement Session", and Formspree gives
   you an endpoint URL like `https://formspree.io/f/abcdwxyz`.
3. In `index.html`, find this line (search for `REPLACE_ME`):

   ```html
   <form id="booking-form" action="https://formspree.io/f/REPLACE_ME" ...>
   ```

   Replace `REPLACE_ME` with your form's ID (the part after `/f/`).
4. Save. Submit a test through the page — you should get an email, and the
   page should show "You're in!" without reloading.

Formspree's free plan includes 50 submissions/month — plenty to start. Every
submission also lands in your Formspree dashboard, so nothing is lost if an
email goes astray.

## 3. Add your Meta Pixel (for ad tracking)

This tells Facebook which ad clicks turned into form submissions, so Meta can
optimize who sees your ad. Skip it to launch faster, but add it soon — it
makes your ad spend meaningfully smarter.

1. In Meta **Events Manager** (business.facebook.com → Events Manager), create
   a Pixel if you don't have one, and copy its **Pixel ID** (a long number).
2. In `index.html`, near the top, find the block that starts with
   `META PIXEL`. Replace **both** occurrences of `REPLACE_ME_PIXEL_ID` with
   your Pixel ID.
3. Make the snippet live: the whole block is currently wrapped in comment
   markers. Delete the `<!--` on the line above `<script>` at the start of
   the block, and delete the `-->` at the very end of the block (the line of
   `═══` symbols ends with it). The `<script>` and `<noscript>` parts should
   no longer be inside a comment.
4. The page already fires a **Lead** event when someone submits the form —
   in Meta Ads Manager, set your campaign to optimize for **Leads**.

## 4. Put it online

**Easiest — Netlify drag-and-drop (free, 2 minutes):**

1. Go to **app.netlify.com** and sign up free.
2. Click **Add new site → Deploy manually**.
3. Drag this whole folder (with `index.html` and your `images` folder inside)
   onto the upload box.
4. Done — you get a live link like `https://something.netlify.app`.
   You can rename it (Site settings → Change site name) to something like
   `lei-free-session.netlify.app`, or connect a custom domain later
   (e.g. `free.leiphotography.co`).
5. **That link is what you paste into your Facebook ad** as the destination.

*(Vercel works the same way — vercel.com → Add New → Project → deploy the
folder. Since your main site already lives on Vercel, either is fine; Netlify
drag-and-drop is just the fewest clicks.)*

**Updating later:** edit `index.html`, then drag the folder onto Netlify
again (Deploys tab → drag to redeploy). It replaces the old version.

---

## Quick pre-launch checklist

- [ ] Photos added (hero + 6 gallery)
- [ ] Formspree ID pasted in, **test submission received by email**
- [ ] Meta Pixel ID pasted in and snippet uncommented
- [ ] Page loads fast on your own phone
- [ ] The scarcity line ("only five free sessions") matches what you actually offer — edit the number in `index.html` if needed
- [ ] Facebook ad's headline matches the page's promise (free engagement session)

## Changing the words

All the copy is plain text inside `index.html` — open it, search for the
sentence you want to change, edit it, save, redeploy. Nothing will break by
editing text between tags.
